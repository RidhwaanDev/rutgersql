var serverlessSDK = require('./serverless_sdk/index.js')
serverlessSDK = new serverlessSDK({
tenantId: 'ridhwaan',
applicationName: 'rutgersgraphql',
appUid: 'LbXxwqqZcZTKDHSWCK',
tenantUid: 'lwtj72Pdkkjpb1Y0Hs',
deploymentUid: '07e31145-1c1f-411d-bea2-e9eb1cd50bfd',
serviceName: 'bus2',
stageName: 'dev'})
const handlerWrapperArgs = { functionName: 'bus2-dev-querytest', timeout: 6}
try {
  const userHandler = require('./handler.js')
  module.exports.handler = serverlessSDK.handler(userHandler.query, handlerWrapperArgs)
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs)
}
