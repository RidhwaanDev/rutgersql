var serverlessSDK = require('./serverless_sdk/index.js')
serverlessSDK = new serverlessSDK({
tenantId: 'ridhwaan',
applicationName: 'rutgersgraphql',
appUid: 'LbXxwqqZcZTKDHSWCK',
tenantUid: 'lwtj72Pdkkjpb1Y0Hs',
deploymentUid: '4b1cdd29-0100-427f-8587-fb34a4b7db90',
serviceName: 'bus2',
stageName: 'dev'})
const handlerWrapperArgs = { functionName: 'bus2-dev-querytest', timeout: 6}
try {
  const userHandler = require('./handler.js')
  module.exports.handler = serverlessSDK.handler(userHandler.query, handlerWrapperArgs)
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs)
}
