var serverlessSDK = require('./serverless_sdk/index.js')
serverlessSDK = new serverlessSDK({
tenantId: 'ridhwaan',
applicationName: 'rutgersgraphql',
appUid: 'LbXxwqqZcZTKDHSWCK',
tenantUid: 'lwtj72Pdkkjpb1Y0Hs',
deploymentUid: '8ebe76e5-8c18-4f2e-99b1-e0468e58a37b',
serviceName: 'bus2',
stageName: 'dev'})
const handlerWrapperArgs = { functionName: 'bus2-dev-querytest', timeout: 6}
try {
  const userHandler = require('./handler.js')
  module.exports.handler = serverlessSDK.handler(userHandler.query, handlerWrapperArgs)
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs)
}
