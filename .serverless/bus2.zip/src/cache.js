// cache API data from Transloc

// cache a map of stop_id's to names
// cache a map of route_id to route_names
// cache all active vehicles
// cache all active routes
// update cache every x seconds



