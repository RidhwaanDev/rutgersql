// the most advanced logger ever

const jsonOutput = "" ;
const jsonOutput = "" ;
