var serverlessSDK = require('./serverless_sdk/index.js')
serverlessSDK = new serverlessSDK({
tenantId: 'ridhwaan',
applicationName: 'rutgersgraphql',
appUid: 'LbXxwqqZcZTKDHSWCK',
tenantUid: 'lwtj72Pdkkjpb1Y0Hs',
deploymentUid: '3017920f-f86e-4245-a647-e88545272a3f',
serviceName: 'bus2',
stageName: 'dev'})
const handlerWrapperArgs = { functionName: 'bus2-dev-query', timeout: 6}
try {
  const userHandler = require('./handler.js')
  module.exports.handler = serverlessSDK.handler(userHandler.query, handlerWrapperArgs)
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs)
}
